package com.example.aula_01.recyclefatima;

public class MinasProgramacao {

    String nome;
    String conteudo;
    String imagem;

    public MinasProgramacao(String nome, String conteudo, String imagem) {
        this.nome = nome;
        this.conteudo = conteudo;
        this.imagem = imagem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }




}
